def details():
    print('Welcome to sus libery')